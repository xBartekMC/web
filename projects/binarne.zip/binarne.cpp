#include <iostream>
using namespace std;

void numberToBin(int l){
    int arr[11], i = 0, num = l;
    
    // dopoki l nie wynosi 0
	while(l != 0){
		arr[i] = l % 2;
		i++;
		l = l / 2;
	}
	cout << num << " jako liczba binarna to ";

	// wypisz w odwrotnej kolejnosci
	for(i = i - 1; i >= 0;i--){
		cout << arr[i];
	}
	cout << endl;
}

int main() {
	int liczba;
	cout<<"Program zamienia liczby na liczby binarne"<<endl;
	cout<<"Podaj liczbe ";
	cin>>liczba;
	numberToBin(liczba);
	system("pause");
	
}
