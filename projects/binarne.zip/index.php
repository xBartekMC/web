<!DOCTYPE html>
<html>
<head>
    <title>Liczby Binarne</title>
</head>
<body>
    <h1>Program zamienia liczby na liczby binarne</h1>
    <form method="post" action="">
        <label for="liczba">Podaj liczbe</label>
        <input type="number" name="liczba" id="liczba" required>
        <input type="submit" value="Convert">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $liczba = intval($_POST["liczba"]);

        function numberToBin($l) {
            $arr = array();
            $i = 0;
            $num = $l;

            // Dopóki $l nie wynosi 0
            while ($l != 0) {
                $arr[$i] = $l % 2;
                $i++;
                $l = (int)($l / 2);
            }

            echo $num . " jako liczba binarna to ";

            // Wypisz w odwrotnej kolejności
            for ($i = $i - 1; $i >= 0; $i--) {
                echo $arr[$i];
            }
            echo "<br>";
        }

        numberToBin($liczba);
    }
    ?>
</body>
</html>
