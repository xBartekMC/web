
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    static void numberToBin(int l){
        ArrayList<Integer> arr = new ArrayList<>();
        int i = 0;
        int num = l;

        // dopoki l nie wynosi 0
        while(l != 0){
            arr.add(i, l % 2);
            i++;
            l = l / 2;
        }
        System.out.println("" + num + " jako liczba binarna to ");

        // wypisz w odwrotnej kolejnosci
        for(i = i - 1; i >= 0;i--){
            System.out.print(arr.get(i));
        }
        System.out.println("");
    }
    public static void main(String[] args) {
        System.out.println("Program zamienia liczby na liczby binarne");
        System.out.print("Podaj liczbe ");
        Scanner scanner = new Scanner(System.in);
        int liczba = scanner.nextInt();
        numberToBin(liczba);

    }
}
